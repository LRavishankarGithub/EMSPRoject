﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EMSProject.Models;

namespace EMSProject.Data
{
    public class EMSProjectContext : DbContext
    {
        public EMSProjectContext (DbContextOptions<EMSProjectContext> options)
            : base(options)
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=172.16.0.240;Database=Test;User ID=sa;Password=Sb@-Db(8&#;MultipleActiveResultSets=true;");
        }

        public DbSet<EMSProject.Models.Employee> Employee { get; set; }
    }
}
